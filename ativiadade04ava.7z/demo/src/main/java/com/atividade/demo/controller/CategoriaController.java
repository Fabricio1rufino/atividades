package com.atividade.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.atividade.demo.model.Categoria;

@Controller
public class CategoriaController {
    private List<Categoria> categorias = new ArrayList<>();

    @GetMapping("/cadastrar_categoria")
    public String cadastrarCategoria(Model model) {
        model.addAttribute("categoria", new Categoria());
        return "cadastrar_categoria";
    }

    @PostMapping("/cadastrar_categoria")
    public String salvarCategoria(@ModelAttribute Categoria categoria) {
        categorias.add(categoria);
        return "redirect:/listar_categorias";
    }

    @GetMapping("/listar_categorias")
    public String listarCategorias(Model model) {
        model.addAttribute("categorias", categorias);
        return "listar_categorias";
    }
}