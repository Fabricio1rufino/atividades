package com.atividade.demo.model;

public enum Status {
    CONCLUIDA,
    ABERTA,
    ATRASADA
}