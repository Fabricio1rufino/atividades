package com.atividade.demo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.atividade.demo.model.Tarefa;
import com.atividade.demo.model.Usuario;

@Controller
public class TarefaController {
    private List<Tarefa> tarefas = new ArrayList<>();

    @Autowired
    private UsuarioController usuarioController; // Injeção do UsuarioController

    @GetMapping("/cadastrar_tarefa")
    public String cadastrarTarefa(Model model) {
        model.addAttribute("tarefa", new Tarefa());
        model.addAttribute("usuarios", usuarioController.getUsuarios()); // Passa a lista de usuários
        return "cadastrar_tarefa";
    }

    @PostMapping("/cadastrar_tarefa")
    public String salvarTarefa(@ModelAttribute Tarefa tarefa, @ModelAttribute Usuario responsavel) {
        tarefa.setDataCriacao(new Date()); // Define a data de criação
        tarefa.setResponsavel(responsavel); // Define o responsável
        tarefas.add(tarefa);
        return "redirect:/listar_tarefas";
    }

    @GetMapping("/listar_tarefas")
    public String listarTarefas(Model model) {
        model.addAttribute("tarefas", tarefas);
        return "listar_tarefas";
    }
}