package com.atividade.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.atividade.demo.model.Usuario;

@Controller
public class UsuarioController {
    private List<Usuario> usuarios = new ArrayList<>();

    @GetMapping("/cadastrar_usuario")
    public String cadastrarUsuario(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "cadastrar_usuario";
    }

    @PostMapping("/cadastrar_usuario")
    public String salvarUsuario(@ModelAttribute Usuario usuario) {
        usuarios.add(usuario);
        return "redirect:/listar_usuarios";
    }

    @GetMapping("/listar_usuarios")
    public String listarUsuarios(Model model) {
        model.addAttribute("usuarios", usuarios);
        return "listar_usuarios";
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }
}